function [nLp, dnLp_dw] = lr_nll(ww, xx, yy)
% LR_NLL negative log-likelihood and gradients for logistic regression
[Lp, dLp_dw] = lr_loglike(ww, xx, yy);
nLp = -Lp;
dnLp_dw = -dLp_dw;
