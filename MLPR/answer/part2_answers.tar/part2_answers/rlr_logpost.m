function Lpost = rlr_logpost(w_e_l, xx, yy)
% RLR_LOGPOST log-posterior (up to a constant) for robust logistic regression
% w_e_l is [ww; epsilon; log_lambda], weights, noise parameter, and log-regularizer
% parameters put into one vector for use with slice_sample.m

% Unpack parameters:
w_e_l = w_e_l(:);
ww = w_e_l(1:end-2);
epsilon = w_e_l(end-1);
log_lambda = w_e_l(end);
lambda = exp(log_lambda);

if (epsilon < 0) || (epsilon > 1)
    Lpost = -Inf;
    return
end

D = numel(ww);
Llike = rlr_loglike(ww, xx, yy, epsilon);
Lpost = Llike - lambda*(ww'*ww) + 0.5*D*log_lambda;
