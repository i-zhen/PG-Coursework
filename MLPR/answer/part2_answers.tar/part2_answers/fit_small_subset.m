N = 100;
ww2 = minimize(zeros(size(x_train,2),1), @lr_nll, 100, x_train(1:N,:), y_train(1:N));
pred2 = 1./(1 + exp(-(x_test*ww2(:))));
report_score(y_test, pred2);

% Outputs:
% Accuracy: 0.775 +/- 0.010    MLP: -Inf

max(ww2)
% Outputs: 57.5833
