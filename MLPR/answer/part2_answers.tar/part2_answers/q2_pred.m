pred = 1./(1 + exp(-(x_test*ww(:))));
report_score(y_test, pred);

% Outputs:
% Accuracy: 0.9151 +/- 0.0069    MLP: -0.209 +/- 0.018
