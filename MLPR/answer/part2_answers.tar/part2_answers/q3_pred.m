D = size(x_train, 2);
all_ww = samples(1:D, :); % DxS
pred_mc = mean(1./(1 + exp(-(x_test*all_ww))), 2);
report_score(y_test, pred_mc);

% Outputs (I didn't clamp the random seed, so not exactly reproducible):
% Accuracy: 0.9151 +/- 0.0069    MLP: -0.189 +/- 0.013
