% Actually make the plot:
clf; hold on;
epsilons = samples(end-1, :);
log_lambdas = samples(end, :);
% Scatter plot of all samples:
plot(epsilons, log_lambdas, '.');
% Overlay path of first 50 iterations:
plot(epsilons(1:50), log_lambdas(1:50), 'r-');
xlabel('\epsilon');
ylabel('log \lambda');

% Export it to a reasonable pdf:
box on
axis tight
set(gcf, 'PaperPosition', [1 1 4 3]*3.5);
set(gca, 'OuterPosition', [0 0 1 1]);
set(gca, 'Position', [0.4 0.4 0.5 0.5]);
print(gcf, 'scatter.eps', '-depsc');
system('epstopdf scatter.eps');
