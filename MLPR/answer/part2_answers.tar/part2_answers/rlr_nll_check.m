randn('state', 0);
rand('state', 0);
D = 3;
N = 5;
xx = randn(N, D);
yy = (rand(N, 1) < 0.5)*2 - 1;
w_a = 0.01*randn(D+1,1);

fprintf('Check close agreement between gradients and finite differences:\n');
hh = 1e-9i;
err = checkgrad(@rlr_nll, w_a, hh, xx, yy)

% Outputs:
% Check close agreement between gradients and finite differences:
%    -0.0204   -0.0204
%    -0.0453   -0.0453
%    -0.9545   -0.9545
%     0.0005    0.0005
% err =
%    1.9562e-16
