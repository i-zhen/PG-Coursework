function [nLp, dnLp_dwa] = rlr_nll(w_a, xx, yy)
% RLR_NLL negative log-likelihood and gradients for robust logistic regression
% w_a is [ww; aa], weights and aa = logit(epsilon)
ww = w_a(1:end-1);
aa = w_a(end);
epsilon = 1/(1+exp(-aa));
[Lp, dLp_dw, dLp_de] = rlr_loglike(ww, xx, yy, epsilon);
nLp = -Lp;
dLp_da = dLp_de*epsilon*(1-epsilon);
dnLp_dwa = -[dLp_dw; dLp_da];
