% Remember train and test inputs should have been augmented as before, then:
w_a = minimize(zeros(size(x_train,2)+1,1), @rlr_nll, 100, x_train, y_train);
ww = w_a(1:end-1);
epsilon = 1/(1 + exp(-w_a(end)))

% Outputs:
% epsilon =
%     0.2028
