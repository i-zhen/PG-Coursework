function rlr_loglike_check()

randn('state', 0);
rand('state', 0);
D = 3;
N = 5;
xx = randn(N, D);
yy = (rand(N, 1) < 0.5)*2 - 1;
ww = 0.01*randn(D,1);
epsilon = rand();


fprintf('Check close agreement between gradients and finite differences:\n');
%hh = 1e-5; % get numerical problems if go smaller
hh = 1e-9i; % Complex step version, allows smaller steps, so more accurate.
%err = checkgrad('rlr_loglike', ww, hh, xx, yy, epsilon) % Only checks dL/dw,
err = checkgrad(@helper, [ww; epsilon], hh, xx, yy) % Also check dL/d_epsilon

function [ff, df] = helper(ww_e, xx, yy)
ww = ww_e(1:end-1);
epsilon = ww_e(end);
[ff, dw, de] = rlr_loglike(ww, xx, yy, epsilon);
df = [dw; de];

% Outputs:
% Check close agreement between gradients and finite differences:
%     0.0093    0.0093
%     0.0220    0.0220
%     0.4542    0.4542
%    -0.0022   -0.0022
% err =
%    1.1936e-16
