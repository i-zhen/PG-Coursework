paired_compare(y_test, pred_mc, pred);

% Outputs:
% Accuracy improvement: 0.0e+00 +/- 0.003    MLP improvement: 0.0201 +/- 0.0064
