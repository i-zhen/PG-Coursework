pred = 1./(1 + exp(-(x_train*ww(:))));
report_score(y_train, pred);

% Outputs (MLP may change slightly if run minimize for longer):
% Accuracy: 0.8334 +/- 0.0046    MLP: -0.4399 +/- 0.0081

pred = 1./(1 + exp(-(x_test*ww(:))));
report_score(y_test, pred);

% Outputs (MLP may change slightly if run minimize for longer):
% Accuracy: 0.9071 +/- 0.0072    MLP: -0.2889 +/- 0.0071
