load text_data.mat
x_train = [x_train, ones(size(x_train,1), 1)];
x_test = [x_test, ones(size(x_test,1), 1)];
