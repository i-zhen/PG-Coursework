% Set up initial state
D = size(x_train, 2);
ww = zeros(D, 1);
epsilon = 0.5;
log_lambda = 0;
w_e_l = [ww; epsilon; log_lambda];

% Slice sample:
S = 1000;
burn = 0; % So we can look at things
widths = 1;
step_out = true;
samples = slice_sample(S, burn, @rlr_logpost, w_e_l, ...
                       widths, step_out, x_train, y_train);

save('samples.mat', 'samples');
