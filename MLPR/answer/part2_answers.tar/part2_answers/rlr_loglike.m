function [Lp, dLp_dw, dLp_de] = rlr_loglike(ww, xx, yy, epsilon)
%RLR_LOGLIKE robust logistic regression log-likelihood and gradients
%
%     [Lp, dLp_dw, dLp_de] = lr_loglike(ww, xx, yy, epsilon);
%
% Inputs:
%          ww Dx1 logistic regression weights
%          xx NxD training data, N feature vectors of length D
%          yy Nx1 labels in {+1,-1} or {1,0}
%     epsilon 1x1 probability of label noise
%
% Outputs:
%          Lp 1x1 log-probability of data, the log-likelihood of ww
%      dLp_dw Dx1 gradients: partial derivatives of Lp wrt ww
%      dLp_de 1x1 gradient: partial derivative of Lp wrt epsilon

% Iain Murray, October 2014, August 2015

% Ensure labels are in {+1,-1}:
yy = (yy==1)*2 - 1;

sigmas = 1./(1 + exp(-yy.*(xx*ww))); % Nx1
pp = (1-epsilon)*sigmas + 0.5*epsilon;
Lp = sum(log(pp));

if nargout > 1
    dLp_dw = xx'*((1-epsilon)*yy.*sigmas.*(1-sigmas)./pp);
end

if nargout > 2
    dLp_de = sum((0.5 - sigmas)./pp);
end
