function paired_compare(y_test, pred1, pred2)
% Report how much better p(y=1) predictions are in pred1 than pred2
y_test = (y_test == 1);
c1 = (y_test == (pred1(:) > 0.5));
c2 = (y_test == (pred2(:) > 0.5));
D_acc = errorbar_str(c1-c2);
Lp1 = [log(pred1(y_test)); log(1 - pred1(~y_test))];
Lp2 = [log(pred2(y_test)); log(1 - pred2(~y_test))];
D_mlp = errorbar_str(Lp1 - Lp2);
fprintf('Accuracy improvement: %s    MLP improvement: %s\n', D_acc, D_mlp);
