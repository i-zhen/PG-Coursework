function report_score(y_test, pred)
% Report quality of p(y=1) predictions in pred
assert(numel(y_test) == numel(pred));
y_test = (y_test(:) == 1);
acc = errorbar_str(y_test == (pred(:) > 0.5));
Lp = [log(pred(y_test)); log(1 - pred(~y_test))];
mlp = errorbar_str(Lp);
fprintf('Accuracy: %s    MLP: %s\n', acc, mlp);
